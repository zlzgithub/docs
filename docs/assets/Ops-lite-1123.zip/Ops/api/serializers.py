# -*- coding: utf-8 -*-
from rest_framework import serializers
from django_celery_beat.models import PeriodicTask

from commons.models import WebSite


class PeriodicTaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = PeriodicTask
        fields = '__all__'


class WebSiteSerializer(serializers.ModelSerializer):
    class Meta:
        model = WebSite
        fields = '__all__'
