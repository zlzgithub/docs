"""Ops URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path, include, re_path
from django.views.static import serve
from django.conf import settings
from consul import views


urlpatterns = [
    path(r'update_consul_data/', views.api_update_consul_data, name='update_consul_data'),
    path(r'read_consul_settings/', views.api_read_consul_settings, name='read_consul_settings'),
    path(r'write_consul_settings/', views.api_write_consul_settings, name='write_consul_settings'),
    # path(r'update_after_deregister/', views.api_update_after_deregister, name='update_after_deregister'),
    re_path(r'get_consul_data/(?P<ds>[0-9]+)/', views.get_consul_data, name='get_consul_data'),
    path(r'consul_data/', views.consul_data, name='consul_data'),
    path(r'service_info/', views.service_info, name='service_info'),
    path(r'get_service_info/', views.get_service_info, name='get_service_info'),
    path(r'consul_registered/', views.consul_registered, name='consul_registered'),
    path(r'service_definition/', views.service_definition, name='service_definition'),
    path(r'get_service_definition/', views.get_service_definition, name='get_service_definition'),
    re_path(r'deregister_service/', views.deregister_service, name='deregister_service'),
    re_path(r'del_service_definition/', views.del_service_definition, name='del_service_definition'),
    path(r'register_service/', views.register_service, name='register_service'),
    path(r'apply_definition/', views.apply_definition, name='apply_definition'),
]
