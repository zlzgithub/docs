import json

import requests
import datetime, time
import random
from django.contrib import auth
from django.http import HttpResponseRedirect, HttpResponse, JsonResponse
from django.shortcuts import redirect, render
from assets.models import *
from users.models import UserProfile
from projs.models import Project
from fort.models import FortServer
from utils.gen_random_code import generate
from utils.decorators import admin_auth
from utils.crypt_pwd import CryptPwd
from utils.db.mongo_ops import MongoOps, JSONEncoder
from io import BytesIO
from django.conf import settings
from commons.tasks import get_login_info
from task.utils.ansible_api_v2 import ANSRunner
from django.contrib.auth.decorators import permission_required
from task.utils.check_tools import CheckTools
from task.models import AnsibleInventory
from conf.logger import ansible_logger, user_logger

mongo = MongoOps(settings.MONGODB_HOST,
                 settings.MONGODB_PORT,
                 settings.RECORD_DB,
                 settings.CONSUL_MONGO_COLL,
                 settings.MONGODB_USER,
                 settings.MONGODB_PASS)


@admin_auth
def consul_data(request):
    return render(request, 'consul/consul_data.html')


@admin_auth
def consul_registered(request):
    return render(request, 'consul/consul_registered.html')


@admin_auth
def service_info(request):
    ansible_logger.info("[service_info] ...")
    s_name = request.GET.get("s_name")
    dc = request.GET.get("dc") or "dc1"
    ansible_logger.info("s_name: " + s_name)
    ds = request.GET.get("ds")
    return render(request, 'consul/service_info.html', locals())


@admin_auth
def get_consul_data(request, ds):
    """
    :param request:
    :param ds: 0 已注册的  1 现存的
    :return:
    """
    draw = int(request.GET.get('draw'))  # 记录操作次數
    start = int(request.GET.get('start'))  # 起始位置
    length = int(request.GET.get('length'))  # 每页长度
    # start_time = request.GET.get('startTime')
    # end_time = request.GET.get('endTime')
    s_name = request.GET.get('s_name')
    order_col = request.GET.get('order[0][column]')
    order_type = 1 if request.GET.get('order[0][dir]') == 'asc' else -1
    dc = request.GET.get('dc')
    search_options = {"ds": int(ds)}
    try:
        if s_name:
            search_options.update({"Name": {"$regex": f".*{s_name}.*"}})
        if dc:
            search_options.update({"dc": dc})
        # if start_time and end_time:
        #     start_time = datetime.datetime.strptime(start_time, '%Y-%m-%d')
        #     end_time = datetime.datetime.strptime(end_time, '%Y-%m-%d') + datetime.timedelta(1)
        #     search_options.update({"datetime": {"$gt": start_time, "$lt": end_time}})
        # searched_data, _ = mongo.find(search_options, start, length, sort_key='Name', sort_method=1)
        searched_data, _ = mongo.find(search_options, start, length, sort_key=order_col, sort_method=order_type)
        _, count = mongo.find(search_options)
        dic = {
            'draw': draw,
            'recordsFiltered': count,
            'recordsTotal': count,
            'data': searched_data
        }
        return HttpResponse(json.dumps(dic, cls=JSONEncoder), content_type='application/json')
    except Exception as e:
        return JsonResponse({'code': 500, 'data': None, 'msg': '获取失败：{}'.format(e)})


@admin_auth
def register_service(request):
    try:
        req_body = json.loads(request.body)
        ansible_logger.info("[register_service] request body:")
        ansible_logger.info(req_body)
        s_id = req_body.get('s_id')
        dc = req_body.get('dc')
        s_name = req_body.get('s_name')
        s_tags = req_body.get('s_tags').split(",")
        ip, port = req_body.get('s_ip_port').split(":")
        s_extra = req_body.get('s_extra')
        payload = {
            "ID": s_id,
            "Name": s_name,
            "Tags": s_tags,
            "Address": ip,
            "Port": int(port)
        }

        if s_extra:
            d_extra = json.loads('{{{d}}}'.format(d=s_extra))
            payload.update(d_extra)
            if not dc and 'dc' in d_extra['Meta']:
                dc = d_extra['Meta']['dc']

        dc = dc or 'dc1'
        ansible_logger.info("final payload:")
        ansible_logger.info(payload)
        url = "http://172.17.0.13:8500/v1/agent/service/register"
        headers = {
            "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
        }

        resp = requests.put(url, data=json.dumps(payload), headers=headers)
        if resp.status_code != 200:
            return JsonResponse({"code": 500, "msg": str(resp.content)})
        else:
            # return update_consul_data(request)  # 请求转发
            return update_after_register(s_name, dc=dc)
    except Exception as e:
        ansible_logger.info("exception:")
        ansible_logger.error(str(e))
        return JsonResponse({"code": 500, "msg": str(e)})


@admin_auth
def register_service00(request):
    try:
        req_body = json.loads(request.body)
        ansible_logger.info("[register_service] request body:")
        ansible_logger.info(req_body)
        s_id = req_body.get('s_id')
        s_name = req_body.get('s_name')
        s_tags = req_body.get('s_tags').split(",")
        ip, port = req_body.get('s_ip_port').split(":")
        s_extra = req_body.get('s_extra')
        payload = {
            "ID": s_id,
            "Name": s_name,
            "Tags": s_tags,
            "Address": ip,
            "Port": int(port)
        }

        if s_extra:
            d_extra = json.loads('{{{d}}}'.format(d=s_extra))
            payload.update(d_extra)

        ansible_logger.info("final payload:")
        ansible_logger.info(payload)
        url = "http://172.17.0.13:8500/v1/agent/service/register"
        headers = {
            "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
        }
        ansible_logger.info("data:")
        ansible_logger.info(json.dumps(payload))

        resp = requests.put(url, data=json.dumps(payload), headers=headers)
        ansible_logger.info("resp.status_code 11:")
        ansible_logger.info(resp.status_code)
        ansible_logger.info(resp.content)
        if resp.status_code != 200:
            ansible_logger.info("<> 200")
            return JsonResponse({"code": 500, "msg": "???"})
        else:
            ansible_logger.info("update ???")
            update_consul_data(request)         # 请求转发 ？？
            ansible_logger.info("update ???222")

    except Exception as e:
        ansible_logger.info("exception: ...")
        ansible_logger.error(str(e))
        return JsonResponse({"code": 500, "msg": str(e)})

    ansible_logger.info("reg end ...")
    return JsonResponse({"code": 200, "msg": "添加成功"})


def update_after_register(s_name, dc="dc1"):
    """
    仅更新被注册的服务
    并检查已注册的同名服务是否需要更新为New状态，或Changed状态
    :param request:
    :return:
    """
    ansible_logger.info("s_name")
    ansible_logger.info(s_name)
    mongo.delete({"ds": 1, "Name": s_name})
    headers = {
        "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
    }
    # resp = requests.get("http://172.17.0.13:8500/v1/health/service/{}?dc={}".format(s_name, dc), headers=headers)
    # ansible_logger.info("resp.content")
    # ansible_logger.info(resp.content)
    resp = requests.get("http://172.17.0.13:8500/v1/internal/ui/services?dc=dc1", headers=headers)
    if 200 == resp.status_code:
        c_data = json.loads(resp.content)
        for c in c_data:
            if s_name == c["Name"]:
                ansible_logger.info("s_name == c.Name, " + s_name)
                c["ds"] = 1
                c["dc"] = dc
                c["Status"] = "Changed"
                mongo.insert_one(c)
                c["ds"] = 0
                del c["_id"]
                mongo.update_insert_one_by_pk_sk(c, pk={"ds": 0, "Name": s_name},
                                                 sk={"$set": {"Status": "Changed +1"},
                                                     "$set_if_not": {"Status": "New"}})
                break
        return JsonResponse({"code": 200, "msg": "update_after_register ok"})
    else:
        return JsonResponse({"code": 500, "msg": "update_after_register failed"})


@admin_auth
def update_after_deregister(request):
    """
    仅更新被注销的服务
    并检查已注册的同名服务是否需要更新为Lost状态，或Changed状态
    :param request:
    :return:
    """
    s_name = request.GET.get("s_name")
    ansible_logger.info("s_name")
    ansible_logger.info(s_name)
    mongo.delete({"ds": 1, "Name": s_name})
    headers = {
        "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
    }
    dc = "dc1"
    resp = requests.get("http://172.17.0.13:8500/v1/health/service/{}?dc={}".format(s_name, dc), headers=headers)
    ansible_logger.info("resp.content")
    ansible_logger.info(resp.content)
    if resp.content == b'[]':
        ansible_logger.info("is b []")
        mongo.update_many(pk={"ds": 0, "Name": s_name}, sk={"$set": {"Status": "Lost"}})
    else:
        mongo.update_many(pk={"ds": 0, "Name": s_name}, sk={"$set": {"Status": "Changed"}})
        # todo
        pass

    return JsonResponse({"code": 200, "msg": "update_after_deregister ok"})


@admin_auth
def update_consul_data(request):
    """
    涉及两个视图的数据，一个是 应注册的， 一个是 实际注册的
    ，更新实际注册的，并对比标记 应注册的 丢失与否
    :param request:
    :return:
    """
    # 获取更新前的数据，以作对比
    # service_data0, count = mongo.find({"ds": 0})

    # 获取最新数据，对比，标记状态
    headers = {
        "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
    }
    resp = requests.get("http://172.17.0.13:8500/v1/internal/ui/services?dc=dc1", headers=headers)
    if 200 == resp.status_code:
        c_data = json.loads(resp.content)
        # mongo.insert_many(c_data)
        # 更新（包括新增）
        for c in c_data:
            c["ds"] = 1
            # mongo.update_insert_one_by_pk_sk(c, pk=["ds", "Name"])
        mongo.delete({"ds": 1})
        mongo.insert_many(c_data)

        # 标记已注册的同名service为正常, 不存在该已注册项则新增一条已注册, 如果存在多余未能匹配的则标记为Lost
        mongo.update_many(pk={"ds": 0}, sk={"$set": {"Status": "Lost"}})
        for c in c_data:
            c["ds"] = 0
            del c["_id"]
            mongo.update_insert_one_by_pk_sk(c, pk=["ds", "Name"],
                                             sk={"$set": {"Status": "OK"},
                                                 "$set_if_not": {"Status": "New"}})

    return JsonResponse({"code": 200, "msg": "更新完毕"})


@admin_auth
def get_service_info(request):
    """
    前端分页即可
    :param request:
    :return:
    """
    ansible_logger.info("[get_service_info]")
    s_name = request.GET.get('s_name')
    dc = request.GET.get('dc') or "dc1"
    ansible_logger.info("s_name={}, dc ={}".format(s_name, dc))
    headers = {
        "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
    }
    resp = requests.get("http://172.17.0.13:8500/v1/health/service/{}?dc={}".format(s_name, dc), headers=headers)
    # resp = requests.get("http://consul-ui.platform.development.yhglobal.cn/v1/internal/ui/services?dc=dc1", headers=headers)
    ansible_logger.info("[get_service_info] resp code:" + str(resp.status_code))
    ansible_logger.info("???")
    if 200 == resp.status_code:
        c_data = json.loads(resp.content)
        # return HttpResponse(json.dumps({'data': c_data}, cls=JSONEncoder), content_type='application/json')
        ansible_logger.info("c_data")
        ansible_logger.info(c_data)
        # get status
        node_check_ok = 1
        node_check_bad = 0
        service_check_ok = 0
        service_check_bad = 0
        # total_node_check = 1
        # total_service_check = 0
        for c in c_data:
            if "Checks" in c:
                if len(c["Checks"]) >= 1:
                    node_check_ok = 1 if c["Checks"][0]["Status"] == "passing" else 0
                    node_check_bad = 1 if c["Checks"][0]["Status"] != "passing" else 0
                if len(c["Checks"]) == 2:
                    service_check_ok = 1 if c["Checks"][1]["Status"] == "passing" else 0
                    service_check_bad = 1 if c["Checks"][1]["Status"] != "passing" else 0
            c["Status"] = {
                "NodeCheckPassing": node_check_ok,
                "NodeCheckNotPassing": node_check_bad,
                "ServiceCheckPassing": service_check_ok,
                "ServiceCheckNotPassing": service_check_bad
            }
            # total_node_check += node_check
            # total_service_check += service_check
        # c_data.append({"TotalNodeCheck": total_node_check})
        # c_data.append({"TotalServiceCheck": total_service_check})
        return JsonResponse({'code': 200, 'data': c_data, 'msg': '获取成功'}, encoder=JSONEncoder)
    else:
        return JsonResponse({'code': 500, 'data': None, 'msg': '获取失败，{}'.format(resp.content)})


@admin_auth
def deregister_service(request):
    """
    注销服务
    :param request:
    :return:
    """
    ansible_logger.info("[deregister_service]")
    s_id = request.POST.get('s_id')
    dc = request.GET.get('dc') or "dc1"
    ansible_logger.info("s_id={}, dc ={}".format(s_id, dc))
    headers = {
        "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
    }
    url_tmpl = "http://172.17.0.13:8500/v1/agent/service/deregister/{id}"
    resp = requests.put(url_tmpl.format(id=s_id), headers=headers)
    if 200 == resp.status_code:
        return JsonResponse({'code': 200, 'msg': '注销成功'}, encoder=JSONEncoder)
    else:
        return JsonResponse({'code': 500, 'msg': '注销失败，{}'.format(resp.content)})
