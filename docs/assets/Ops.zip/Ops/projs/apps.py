from django.apps import AppConfig


class ProjsConfig(AppConfig):
    name = 'projs'
