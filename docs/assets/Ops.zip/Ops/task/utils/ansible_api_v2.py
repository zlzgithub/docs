# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：      ansible_api
   Description:
   Author:          Administrator
   date：           2018/6/11
-------------------------------------------------
   Change Activity:
                    2018/6/11:
-------------------------------------------------
"""
import json
import re

from ansible import constants as C
from collections import namedtuple
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.executor.playbook_executor import PlaybookExecutor
from ansible.plugins.callback import CallbackBase
from ansible.inventory.manager import InventoryManager
from ansible.vars.manager import VariableManager

from projs.utils.deploy_websocket import DeployResultsCollector
from conf.logger import ansible_logger
from django.conf import settings
from concurrent.futures import ThreadPoolExecutor
from assets.models import ServerAssets
from utils.crypt_pwd import CryptPwd


class ModuleResultsCollector(CallbackBase):
    """
    直接执行模块命令的回调类
    """

    def __init__(self, sock=None, *args, **kwargs):
        super(ModuleResultsCollector, self).__init__(*args, **kwargs)
        self.module_results = []
        self.module_html = []
        self.sock = sock

    def v2_runner_on_unreachable(self, result):
        if 'msg' in result._result:
            stdout = result._result.get('msg').encode().decode('utf-8')
            data = '<code style="color: #FF0000">{host} | unreachable | rc={rc} >></code><br>' \
                   '<code style="color: #FF0000>{stdout}</code><br>'.format(host=result._host.name,
                                                                            rc=result._result.get(
                                                                                'rc'),
                                                                            stdout=stdout)
        else:
            stdout = json.dumps(result._result, indent=4, ensure_ascii=False)
            data = '<code style="color: #FF0000">{host} | unreachable >></code><br>' \
                   '<code style="color: #FF0000>{stdout}</code><br>'.format(host=result._host.name,
                                                                            stdout=stdout)
        if self.sock:
            self.sock.send(data)
        self.module_html.append(data)
        self.module_results.append(stdout)

    def v2_runner_on_ok(self, result, *args, **kwargs):
        if 'rc' in result._result and 'stdout' in result._result:
            stdout = result._result.get('stdout').encode().decode('utf-8')
            data = '<code style="color: #00E000">{host} | success | rc={rc} >></code><br>' \
                   '<code style="color: #FFFFFF">{stdout}</code><br><br>' \
                .format(host=result._host.name,
                        rc=result._result.get('rc'),
                        stdout=stdout)
        elif 'results' in result._result and 'rc' in result._result:
            stdout = result._result.get('results')[0].encode().decode('utf-8')
            data = '<code style="color: #00E000">{host} | success | rc={rc} >></code><br>' \
                   '<code style="color: #FFFFFF">{stdout}</code><br><br>' \
                .format(host=result._host.name,
                        rc=result._result.get('rc'),
                        stdout=stdout)
        elif 'module_stdout' in result._result and 'rc' in result._result:
            stdout = result._result.get('module_stdout').encode().decode('utf-8')
            data = '<code style="color: #00E000">{host} | success | rc={rc} >></code><br>' \
                   '<code style="color: #FFFFFF">{stdout}</code><br><br>' \
                .format(host=result._host.name,
                        rc=result._result.get('rc'),
                        stdout=stdout)
        else:
            stdout = json.dumps(result._result, indent=4, ensure_ascii=False)
            data = '<code style="color: #00E000">{host} | success >></code><br>' \
                   '<code style="color: #FFFFFF">{stdout}</code><br><br>' \
                .format(host=result._host.name,
                        stdout=stdout)
        if self.sock:
            self.sock.send(data)
        self.module_html.append(data)
        self.module_results.append(stdout)

    def v2_runner_on_failed(self, result, *args, **kwargs):
        if 'stderr' in result._result:
            stdout = result._result.get('stderr').encode().decode('utf-8')
            data = '<code style="color: #FF0000">{host} | failed | rc={rc} >></code><br>' \
                   '<code style="color: #FF0000">{stdout}</code><br>'.format(host=result._host.name,
                                                                             rc=result._result.get(
                                                                                 'rc'),
                                                                             stdout=stdout)
        elif 'module_stdout' in result._result:
            stdout = result._result.get('module_stdout').encode().decode('utf-8')
            data = '<code style="color: #FF0000">{host} | failed | rc={rc} >></code><br>' \
                   '<code style="color: #FF0000">{stdout}</code><br>'.format(host=result._host.name,
                                                                             rc=result._result.get(
                                                                                 'rc'),
                                                                             stdout=stdout)
        else:
            stdout = json.dumps(result._result, indent=4, ensure_ascii=False)
            data = '<code style="color: #FF0000">{host} | failed >></code><br>' \
                   '<code style="color: #FF0000">{stdout}</code><br>'.format(host=result._host.name,
                                                                             stdout=stdout)
        if self.sock:
            self.sock.send(data)
        self.module_html.append(data)
        self.module_results.append(stdout)


class PlayBookResultsCollector(CallbackBase):
    """
    执行playbook的回调类
    """

    def __init__(self, sock, *args, **kwargs):
        super(PlayBookResultsCollector, self).__init__(*args, **kwargs)
        self.playbook_results = []
        self.sock = sock

    def v2_playbook_on_play_start(self, play):
        name = play.get_name().strip()
        if not name:
            msg = '<code style="color: #00FF00">\nPLAY\n{}\n</code>'.format('=' * 120)
        else:
            msg = '<code style="color: #00FF00">\nPLAY [{}]\n{}\n</code>'.format(name, '=' * 120)
        self.send_save(msg)

    def v2_playbook_on_task_start(self, task, is_conditional):
        msg = '<code style="color: #FFFFFF">\nTASK [{}]\n{}\n</code>'.format(task.get_name(),
                                                                             '*' * 120)
        self.send_save(msg)

    def v2_runner_on_ok(self, result, *args, **kwargs):
        if result.is_changed():
            if 'stdout' in result._result:
                data = '<code style="color: #FFFF00">[{}]=> changed:\n{}</code>\n'.format(
                    result._host.name, result._result['stdout'])
            else:
                data = '<code style="color: #FFFF00">[{}]=> changed</code>\n'.format(
                    result._host.name)
        else:
            if 'stdout' in result._result:
                data = '<code style="color: #00E000">[{}]=> ok:\n{}</code>\n'.format(
                    result._host.name, result._result['stdout'])
            elif 'msg' in result._result:
                data = '<code style="color: #00E000">[{}]=> ok:\n{}</code>\n'.format(
                    result._host.name, result._result['msg'])
            else:
                data = '<code style="color: #00E000">[{}]=> ok</code>\n'.format(result._host.name)
        self.send_save(data)

    def v2_runner_on_failed(self, result, *args, **kwargs):
        if 'changed' in result._result:
            del result._result['changed']
        data = '<code style="color: #FF0000">[{}]=> {}: {}\n</code>'.format(result._host.name,
                                                                            'failed',
                                                                            self._dump_results(
                                                                                result._result))
        self.send_save(data)

    def v2_runner_on_unreachable(self, result):
        if 'changed' in result._result:
            del result._result['changed']
        data = '<code style="color: #FF0000">[{}]=> {}: {}\n</code>'.format(result._host.name,
                                                                            'unreachable',
                                                                            self._dump_results(
                                                                                result._result))
        self.send_save(data)

    def v2_runner_on_skipped(self, result):
        if 'changed' in result._result:
            del result._result['changed']
        data = '<code style="color: #FFFF00">[{}]=> {}: {}</code>\n' \
            .format(result._host.name, 'skipped', self._dump_results(result._result))
        self.send_save(data)

    def v2_playbook_on_stats(self, stats):
        hosts = sorted(stats.processed.keys())
        data = '<code style="color: #00FF00">\nPLAY RECAP\n{}\n</code>'.format('=' * 120)
        self.send_save(data)
        for h in hosts:
            s = stats.summarize(h)
            msg = '<code style="color: #FFFFFF">{} : ok={} changed={}' \
                  ' unreachable={} failed={} skipped={}</code>\n' \
                .format(h, s['ok'], s['changed'], s['unreachable'], s['failures'], s['skipped'])
            self.send_save(msg)

    def send_save(self, data):
        self.sock.send(data)
        self.playbook_results.append(data)


class MyInventory(InventoryManager):
    """
    用于动态生成Inventory的类.
    """

    def __init__(self, loader, resource=None, sources=None):
        """
        resource的数据格式是一个列表字典，比如
            {
                "group1": {
                    "hosts": [{"ip": "10.0.0.0", "port": "22", "username": "test", "password": "pass"}, ...],
                    "group_vars": {"var1": value1, "var2": value2, ...}
                }
            }
             如果你只传入1个列表，这默认该列表内的所有主机属于default 组,比如
            [{"ip": "10.0.0.0", "port": "22", "username": "test", "password": "pass"}, ...]
        sources是原生的方法，参数是配置的inventory文件路径，可以指定一个，也可以以列表的形式可以指定多个
        """
        super(MyInventory, self).__init__(loader=loader, sources=sources)
        self.resource = resource
        self.dynamic_inventory()

    def add_dynamic_group(self, hosts, group_name, group_vars=None):
        """
        将从数据库读取的组信息，主机信息等生成的resource信息解析成ansible可以读取的内容
        :param hosts: 包含主机所有信息的的列表
        :type hosts: list
        :param group_name:
        :param group_vars:
        :type group_vars: dict
        :return:
        """
        # 添加主机组
        self.add_group(group_name)

        # 添加主机组变量
        if group_vars:
            for key, value in group_vars.items():
                self.groups[group_name].set_variable(key, value)

        for host in hosts:
            ip = host.get('ip')
            port = host.get('port')

            # 添加主机到主机组
            self.add_host(ip, group_name, port)

            username = host.get('username')
            password = host.get('password')

            # 生成ansible主机变量
            self.get_host(ip).set_variable('ansible_ssh_host', ip)
            self.get_host(ip).set_variable('ansible_ssh_port', port)
            self.get_host(ip).set_variable('ansible_ssh_user', username)
            self.get_host(ip).set_variable('ansible_ssh_pass', password)
            self.get_host(ip).set_variable('ansible_sudo_pass', password)

            # 如果使用同一个密钥管理所有机器，只需把下方的注释去掉，ssh_key指定密钥文件，若是不同主机使用不同密钥管理，则需要单独设置主机变量或组变量
            # self.get_host(ip).set_variable('ansible_ssh_private_key_file', ssh_key)

            # set other variables
            for key, value in host.items():
                # if key not in ["ip", "port", "username", "password"]:
                if key not in ["username", "password"]:
                    self.get_host(ip).set_variable(key, value)

    def dynamic_inventory(self):
        if isinstance(self.resource, list):
            self.add_dynamic_group(self.resource, 'default')
        elif isinstance(self.resource, dict):
            for groupname, hosts_and_vars in self.resource.items():
                self.add_dynamic_group(hosts_and_vars.get("hosts"), groupname,
                                       hosts_and_vars.get("group_vars"))


class ANSRunner(object):
    """
    执行ansible模块或者playbook的类，这里默认采用了用户名+密码+sudo的方式
    """
    check_result = []
    stdout = []
    sock = None

    def __init__(self, resource=None, sources=None, sock=None, **kwargs):
        Options = namedtuple('Options',
                             ['connection', 'module_path', 'forks', 'timeout', 'remote_user',
                              'ask_pass', 'private_key_file', 'ssh_common_args', 'ssh_extra_args',
                              'sftp_extra_args', 'strategy',
                              'scp_extra_args', 'become', 'become_method', 'become_user',
                              'ask_value_pass',
                              'verbosity', 'retry_files_enabled',
                              'check', 'listhosts', 'listtasks', 'listtags', 'syntax', 'diff',
                              'gathering', 'roles_path'])
        self.options = Options(connection='smart',
                               module_path=None,
                               forks=50, timeout=kwargs.get('timeout', 10),
                               remote_user=kwargs.get('remote_user', None), ask_pass=False,
                               private_key_file=None,
                               ssh_common_args=None,
                               ssh_extra_args=None,
                               sftp_extra_args=None, strategy='free', scp_extra_args=None,
                               become=kwargs.get('become', None),
                               become_method=kwargs.get('become_method', None),
                               become_user=kwargs.get('become_user', None), ask_value_pass=False,
                               verbosity=None,
                               retry_files_enabled=False, check=False, listhosts=False,
                               listtasks=False, listtags=False, syntax=False, diff=True,
                               gathering='smart',
                               roles_path=settings.ANSIBLE_ROLE_PATH)
        self.loader = DataLoader()
        self.inventory = MyInventory(resource=resource, loader=self.loader, sources=sources)
        self.variable_manager = VariableManager(loader=self.loader, inventory=self.inventory)
        self.passwords = dict(sshpass=None, becomepass=None)
        self.callback = None
        self.sock = sock

    def run_module(self, host_list, module_name, module_args, deploy=False, send_msg=True):
        """
        run module from ansible ad-hoc.
        """
        self.callback = DeployResultsCollector(self.sock, send_msg=send_msg) \
            if deploy else ModuleResultsCollector(sock=self.sock)

        play_source = dict(
            name="Ansible Play",
            hosts=host_list,
            gather_facts='no',
            tasks=[dict(action=dict(module=module_name, args=module_args))]
        )

        play = Play().load(play_source, variable_manager=self.variable_manager, loader=self.loader)

        # actually run it
        tqm = None

        try:
            tqm = TaskQueueManager(
                inventory=self.inventory,
                variable_manager=self.variable_manager,
                loader=self.loader,
                options=self.options,
                passwords=self.passwords,
                stdout_callback=self.callback,
            )

            C.HOST_KEY_CHECKING = False
            tqm.run(play)
        except Exception as e:
            ansible_logger.error('执行{}失败，原因: {}'.format(module_name, e))
        finally:
            if tqm is not None:
                tqm.cleanup()

    def run_playbook(self, playbook_path, extra_vars=None):
        """
        run ansible playbook
        """
        try:
            self.callback = PlayBookResultsCollector(sock=self.sock)
            if extra_vars:
                self.variable_manager.extra_vars = extra_vars
            executor = PlaybookExecutor(
                playbooks=[playbook_path],
                inventory=self.inventory,
                variable_manager=self.variable_manager,
                loader=self.loader,
                options=self.options,
                passwords=self.passwords
            )
            executor._tqm._stdout_callback = self.callback
            C.HOST_KEY_CHECKING = False
            executor.run()
        except Exception as e:
            ansible_logger.error('执行{}失败，原因: {}'.format(playbook_path, e))

    @property
    def get_module_results(self):
        return self.callback.module_results

    @property
    def get_module_html(self):
        return self.callback.module_html

    @property
    def get_playbook_results(self):
        return self.callback.playbook_results

    @staticmethod
    def handle_setup_data(data):
        """处理setup模块数据，用于收集服务器信息功能"""
        server_facts = {}
        result = json.loads(data[data.index('{'): data.rindex('}') + 1])
        facts = result['ansible_facts']
        server_facts['hostname'] = facts['ansible_hostname']
        server_facts['cpu_model'] = facts['ansible_processor'][-1]
        server_facts['cpu_number'] = int(facts['ansible_processor_count'])
        server_facts['vcpu_number'] = int(facts['ansible_processor_vcpus'])
        server_facts['disk_total'], disk_size = 0, 0
        for k, v in facts['ansible_devices'].items():
            if k[0:2] in ['sd', 'hd', 'ss', 'vd']:
                if 'G' in v['size']:
                    disk_size = float(v['size'][0: v['size'].rindex('G') - 1])
                elif 'T' in v['size']:
                    disk_size = float(v['size'][0: v['size'].rindex('T') - 1]) * 1024
                server_facts['disk_total'] += round(disk_size, 2)
        server_facts['ram_total'] = round(int(facts['ansible_memtotal_mb']) / 1024)
        server_facts['kernel'] = facts['ansible_kernel']
        server_facts['system'] = '{} {} {}'.format(facts['ansible_distribution'],
                                                   facts['ansible_distribution_version'],
                                                   facts['ansible_userspace_bits'])
        server_model = facts['ansible_product_name']

        # 获取网卡信息
        nks = []
        for nk in facts.keys():
            networkcard_facts = {}
            if re.match(r"^ansible_(eth|bind|eno|ens|em)\d+?", nk):
                networkcard_facts['network_card_name'] = facts.get(nk).get('device')
                networkcard_facts['network_card_mac'] = facts.get(nk).get('macaddress')
                networkcard_facts['network_card_ip'] = facts.get(nk).get('ipv4').get(
                    'address') if 'ipv4' in facts.get(
                    nk) else 'unknown'
                networkcard_facts['network_card_model'] = facts.get(nk).get('type')
                networkcard_facts['network_card_mtu'] = facts.get(nk).get('mtu')
                networkcard_facts['network_card_status'] = 1 if facts.get(nk).get('active') else 0
                nks.append(networkcard_facts)
        return server_facts, server_model, nks

    @staticmethod
    def handle_mem_data(data):
        """
        处理获取的内存信息
        :param data: 通过ansible获取的内存信息
        :return:
        """
        result = json.loads(data[data.index('{'): data.rindex('}') + 1])
        facts = result['ansible_facts']
        return facts['mem_info']

    @staticmethod
    def gen_ip_pairs(str_host_list, sock=None):
        """
        生成ip_pairs
        :param str_host_list: str类型
        :param sock:
        :return:
        """
        if not isinstance(str_host_list, str):
            return []

        patt = re.compile('[,，\\s]+')
        host_list = patt.sub(' ', str_host_list).strip().split(' ')
        ip_pairs = []
        if not host_list:
            if sock:
                sock.send(
                    '<code style="color: #FF0000">\nansible执行模块出错：hosts未指定\n</code>')
        else:
            if len(host_list) == 1:
                host_list.append(settings.SERVER_IP)
            for i in range(len(host_list) - 1):
                ip_pairs.append((host_list[i], host_list[i + 1]))
        return ip_pairs

    @staticmethod
    def run_check(ip_pair=None, sock=None):
        """
        执行检测（多线程执行单元）
        :param ip_pair: str类型，如"123.45.67.89,..."
        :param sock:
        :return:
        """
        ip, ip2 = ip_pair.split(',')
        res = []  # 当前ip_pair的命令结果
        try:
            server_obj = ServerAssets.objects.select_related('assets').get(
                assets__asset_management_ip=ip)
            resource = [{"ip": server_obj.assets.asset_management_ip,
                         "port": int(server_obj.port),
                         "username": server_obj.username,
                         "password": CryptPwd().decrypt_pwd(server_obj.password)}]
            ans = ANSRunner(resource, become='yes', become_method='sudo', become_user='root',
                            sock=sock, timeout=5)
            # ping序列检测命令
            module_args = """ping -c 100 -i 0.002 -w 2 {} |tail -n2""" \
                          """ |sed 's#[^0-9%\.]\+#,#g;s/^,\+//;s/,\+$//;'""" \
                          '|sed ":a;N;s/\\n/,/g;ta"'.format(ip2)
            ansible_logger.info("current module_args is:")
            ansible_logger.info(module_args)
            ans.run_module(host_list=[ip],
                           module_name="shell",
                           module_args=module_args)
            res.extend(ans.get_module_results)
            ANSRunner.stdout.extend(ans.get_module_html)
        except Exception as e:
            # ansible未能执行的，不能通过ans.get_module_results获取结果，设定结果为error
            ANSRunner.stdout.append('<code style="color: #FF0000">{}->{}: failed. {}</code><br><br>'
                                    .format(ip, ip2, e))
            res.append("error")
            ansible_logger.error(e)
        finally:
            ansible_logger.info("current res(result) is:")
            ansible_logger.info(res)
            ansible_logger.info("current stdout(html) is:")
            ansible_logger.info(ANSRunner.stdout)
            # 对结果判定
            status = "error"
            str_res = ','.join(res)
            if 'error' in str_res:
                status = "error"
            elif '%' in str_res:
                per = int(str_res.split('%')[0].split(',')[-1])
                if per < 5:
                    status = "succeed"
                elif per < 20:
                    status = "unstable"
                else:
                    status = "failed"
            ANSRunner.check_result.append({"tag": ip + "->" + ip2,
                                           "ip": ip,
                                           "ip2": ip2,
                                           "result": '\n'.join(res),
                                           "status": status})
            ansible_logger.info("current check_result is:")
            ansible_logger.info(ANSRunner.check_result)

    @staticmethod
    def check_ping(str_host_list=None, sock=None, mode="parallel"):
        """
        多线程执行
        :param str_host_list: ip列表 "123.45.67.89, ..."
        :param sock: websocket对象
        :param mode: parallel多线程并发模式 非parallel单线程 默认parallel
        :return: 成功则返回{'code': 200,
                'msg': '获取成功',
                'result': ANSRunner.check_result,
                'stdout': ANSRunner.stdout}
        """
        ip_pairs = ANSRunner.gen_ip_pairs(str_host_list)
        if not ip_pairs:
            return {'code': 500, 'msg': "参数host_list类型错误"}

        # 清空全局变量
        ANSRunner.check_result = []
        ANSRunner.stdout = []

        if "parallel" == mode:
            # 多线程方式
            future = ThreadPoolExecutor(20)
            for ip_pair in ip_pairs:
                try:
                    ansible_logger.info("In threads: " + str(ip_pair))
                    a = ','.join(ip_pair)
                    # future.submit(ANSRunner.run_check, (a, sock,)) # 参数形式错误？
                    future.submit(ANSRunner.run_check, a, sock)
                except Exception as e:
                    ansible_logger.info(e)
            future.shutdown(wait=True)      # 释放资源
        else:
            # 单线程方式
            for ip_pair in ip_pairs:
                try:
                    a = ','.join(ip_pair)
                    ANSRunner.run_check(ip_pair=a, sock=sock)
                except Exception as e:
                    ansible_logger.info(e)

        ansible_logger.info("ANSRunner.check_result:")
        ansible_logger.info(ANSRunner.check_result)
        ansible_logger.info("ANSRunner.stdout:")
        ansible_logger.info(ANSRunner.stdout)
        return {'code': 200,
                'msg': '获取成功',
                'result': ANSRunner.check_result,
                'stdout': ANSRunner.stdout}
