# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：      consumers
   Description:
   Author:          Administrator
   date：           2018/6/6
-------------------------------------------------
   Change Activity:
                    2018/6/6:
-------------------------------------------------
"""
import json
import os
from django.conf import settings
from task.tasks import playbook_record
from task.models import AnsiblePlaybook
from users.models import UserProfile
from utils.db.redis_ops import RedisOps
from task.utils.ansible_api_v2 import ANSRunner
from task.utils.gen_resource import GenResource
from channels.generic.websocket import WebsocketConsumer
from conf.logger import ansible_logger
from task.views import get_playbook_file_path, parse_hosts
import random, string


class AnsPlaybookConsumer(WebsocketConsumer):

    def __init__(self, *args, **kwargs):
        super(AnsPlaybookConsumer, self).__init__(*args, **kwargs)
        self.redis_instance = RedisOps(settings.REDIS_HOST, settings.REDIS_PORT, 4,
                                       password=settings.REDIS_PASSWORD)
        self.ans_info = None

    def connect(self):
        self.accept()

    def receive(self, text_data=None, bytes_data=None):
        self.ans_info = json.loads(text_data)

        group_ids = self.ans_info['group_ids']
        ansible_logger.info("group_ids:")
        ansible_logger.info(group_ids)
        playbook_id = self.ans_info['playbook_id']

        self.run_playbook(group_ids, playbook_id)

    def disconnect(self, code):
        pass

    def run_playbook(self, group_ids, playbook_id):
        playbook = AnsiblePlaybook.objects.select_related('playbook_user').get(id=playbook_id)
        unique_key = '{}.{}'.format(playbook.playbook_name, group_ids)

        if self.redis_instance.get(unique_key):
            self.send('<code style="color: #FF0000">\n有相同的任务正在进行！请稍后重试！\n</code>', close=True)
        else:
            try:
                self.redis_instance.set(unique_key, 1)
                gid, hosts_content = parse_hosts([], playbook.hosts_content)
                if group_ids or hosts_content:
                    # 动态主机组资源
                    resource = None
                    sources = None
                    if group_ids:
                        resource = GenResource().gen_group_dict(group_ids)

                    # 静态资源清单
                    tmp_hosts = ""
                    if hosts_content:
                        hosts_id = ''.join(random.sample(string.ascii_letters + string.digits, 8))
                        ansible_logger.info("hosts id is: " + hosts_id)
                        tmp_hosts = '/tmp/hosts_{}'.format(hosts_id)
                        sources = [tmp_hosts]
                        with open(tmp_hosts, 'w') as f:
                            f.write(hosts_content)

                    ans = ANSRunner(resource=resource, sources=sources, sock=self)
                    ansible_logger.info("ans:")
                    ansible_logger.info(ans)
                    ans.run_playbook(get_playbook_file_path(playbook))
                    playbook_record.delay(
                        playbook_user=UserProfile.objects.get(id=self.ans_info['run_user']),
                        playbook_remote_ip=self.ans_info['remote_ip'],
                        playbook_name=playbook.playbook_name,
                        playbook_result=ans.get_playbook_results
                    )
                    if tmp_hosts:
                        os.remove(tmp_hosts)
                else:
                    self.send(
                        '<code style="color: #FF0000">\n未知inventory.\n</code>')
            except Exception as e:
                self.send(
                    '<code style="color: #FF0000">\nansible执行playbook出错：{}\n</code>'.format(str(e)))
            finally:
                self.redis_instance.delete(unique_key)
                self.close()
