# -*- coding: utf-8 -*-

import re
from django.conf import settings
from assets.models import ServerAssets
from conf.logger import ansible_logger
from task.utils.ansible_api_v2 import ANSRunner
from utils.crypt_pwd import CryptPwd
from concurrent.futures import ThreadPoolExecutor


class CheckTools(object):
    # 写在init里面？
    check_result = []
    stdout = []

    @staticmethod
    def color_str(s, color="#FF0000"):
        return '{}<code style="color: {}">'.format(s, color)

    @staticmethod
    def color_str2(s, color="#FF0000"):
        return '<code style="color: {}">{}</code>'.format(color, s)

    def __init__(self, str_host_list=None, sock=None):
        """
        str_host_list标准形式："ip1,ip2,ip3,...;ip1,ip3,ip5,...;ip2,ip6,ip7,...;..."
        :param str_host_list: 多条ip链以分号分隔，每条ip链内ip以逗号分隔的字符串
        :param sock:
        """

        self.all_status = {"0": "succ:", "1": "un:", "2": "fail:", "3": "err:"}
        self.all_status_html = {"0": CheckTools.color_str("succ:", "#00FF00"),
                                "1": CheckTools.color_str("un:", "#FFE229"),
                                "2": CheckTools.color_str("fail:", "#ff6d17"),
                                "3": CheckTools.color_str("err:", "#FF0000")}
        self.all_status2 = {"0": "succeed", "1": "unstable", "2": "failed", "3": "error"}
        self.all_status_html2 = {"0": CheckTools.color_str2("succeed", "#00FF00"),
                                 "1": CheckTools.color_str2("unstable", "#FFE229"),
                                 "2": CheckTools.color_str2("failed", "#ff6d17"),
                                 "3": CheckTools.color_str2("error", "#FF0000")}
        self.str_host_list = str_host_list
        ansible_logger.info("self.str_host_list:")
        ansible_logger.info(self.str_host_list)
        self.host_list = []
        self.sock = sock
        self.ip_pairs, self.uniq_ip_pairs, self.del_ip_pairs, self.dict_ip_pairs, self.sorted_ip_pairs, self.ogz_ip_pair = self.gen_ip_pairs()

    def gen_ip_pairs(self):
        """
        处理类参数str_host_list，生成各种形式的ip列表：
            ip_pairs形式：[(ip1,ip2),(ip2,ip3),(ip3,ip4),...]
            uniq_ip_pairs：即 set(ip_pairs)
            del_ip_pairs：可能需去除的ip对，相邻链尾链首组成的ip对可能需要剔除
                形如["ip1;ip2", "ip2:ip5", ...]，处理后["ip1,ip2", "ip2,ip5", ...]，可能重复
            dict_ip_pairs形式：{"ip1,ip2": n1,"ip2,ip3": n2,...}
            sorted_ip_pairs：即 sorted(dict_ip_pairs)
            ogz_ip_pair形式：{"ip1": [ip2,ip3,...], "ip2": [ip3,ip5,...],...}
                即 对去重后的ip_pairs，左ip相同的聚合成一个kv
        :return:
        """
        if not isinstance(self.str_host_list, str):
            return [], [], [], {}, [], {}

        patt = re.compile('[,，;；\\s]+')
        self.host_list = patt.sub(' ', self.str_host_list).strip().split(' ')
        ip_pairs = []
        if self.host_list:
            if len(self.host_list) == 1:
                self.host_list.append(settings.SERVER_IP)
            for i in range(len(self.host_list) - 1):
                ip_pairs.append((self.host_list[i], self.host_list[i + 1]))

        uniq_ip_pairs = set(ip_pairs)
        dict_ip_pairs = {}
        for ip_pair in uniq_ip_pairs:
            k = ','.join(ip_pair)
            dict_ip_pairs.setdefault(k, ip_pairs.count(ip_pair))

        # 统计 可能需去除的ip对
        patt2 = re.compile('[0-9\.]+\s*;\s*[0-9\.]+')
        del_ip_pairs0 = patt2.findall(self.str_host_list)
        del_ip_pairs = [str(e).replace(';', ',').replace('\n', '') for e in del_ip_pairs0]
        dict_del_ip_pairs = {}
        for ip_p in set(del_ip_pairs):
            dict_del_ip_pairs.setdefault(ip_p, del_ip_pairs.count(ip_p))

        # ansible_logger.info("del_ip_pairs:")
        # ansible_logger.info(del_ip_pairs)
        # ansible_logger.info("dict_del_ip_pairs:")
        # ansible_logger.info(dict_del_ip_pairs)

        # 重组ip
        for ip_p in set(del_ip_pairs):
            if dict_ip_pairs[ip_p] == dict_del_ip_pairs.get(ip_p):
                # 非相等 则认为需保留，否则剔除
                del dict_ip_pairs[ip_p]

        sorted_ip_pairs = sorted(dict_ip_pairs)
        ogz_ip_pair = {}
        for ip_pair in sorted_ip_pairs:
            ip_left, ip_right = str(ip_pair).split(',')
            ogz_ip_pair.setdefault(ip_left, []).append(ip_right)

        # ansible_logger.info("ip_pairs:")
        # ansible_logger.info(ip_pairs)
        # ansible_logger.info("uniq_ip_pairs:")
        # ansible_logger.info(uniq_ip_pairs)
        # ansible_logger.info("del_ip_pairs:")
        # ansible_logger.info(del_ip_pairs)
        # ansible_logger.info("dict_ip_pairs:")
        # ansible_logger.info(dict_ip_pairs)
        # ansible_logger.info("sorted_ip_pairs:")
        # ansible_logger.info(sorted_ip_pairs)
        # ansible_logger.info("ogz_ip_pair:")
        # ansible_logger.info(ogz_ip_pair)
        return ip_pairs, uniq_ip_pairs, del_ip_pairs, dict_ip_pairs, sorted_ip_pairs, ogz_ip_pair

    # def check_ping000(self, mode='parallel'):
    #     """
    #     弃用方法
    #     :param mode:
    #     :return:
    #     """
    #     if not self.ip_pairs:
    #         return {'code': 500, 'msg': "参数错误: ip_pairs"}
    #
    #     self.check_result = []
    #     self.stdout = []
    #     if 'parallel' == mode:
    #         # 多线程
    #         ansible_logger.info("parallel ...")
    #         future = ThreadPoolExecutor(20)
    #         for ip_pair in self.ip_pairs:
    #             ansible_logger.info(ip_pair)
    #             try:
    #                 a = ','.join(ip_pair)
    #                 future.submit(self.run_check, a)
    #             except Exception as e:
    #                 ansible_logger.info(e)
    #         future.shutdown(wait=True)
    #     else:
    #         # 单线程
    #         ansible_logger.info("serial ...")
    #         for ip_pair in self.ip_pairs:
    #             ansible_logger.info(ip_pair)
    #             try:
    #                 a = ','.join(ip_pair)
    #                 self.run_check(a)  # 字符串a
    #             except Exception as e:
    #                 ansible_logger.info(e)
    #
    #     ansible_logger.info(self.check_result)
    #     ansible_logger.info(self.stdout)
    #     return {'code': 200,
    #             'msg': '获取成功',
    #             'result': self.check_result,
    #             'stdout': self.stdout}

    def check_ping(self, mode='parallel'):
        """
        基于重组后的ip ping检测
        :param mode: parallel多线程并发模式 非parallel单线程 默认parallel
        :return: 成功返回{'code': 200,
                'msg': '获取成功',
                'result': self.check_result,
                'stdout': self.stdout}
        """

        if not self.ip_pairs:
            return {'code': 500, 'msg': "参数错误: ip_pairs"}

        # 清空已有结果？
        self.check_result = []
        self.stdout = []
        if 'parallel' == mode:
            # 多线程
            ansible_logger.info("多线程 ...")
            future = ThreadPoolExecutor(20)
            for ip, ip2 in self.ogz_ip_pair.items():
                try:
                    str_ips = ip + "," + " ".join(ip2)
                    ansible_logger.info(str_ips)
                    future.submit(self.run_check, str_ips)
                except Exception as e:
                    ansible_logger.info(e)
            future.shutdown(wait=True)
        else:
            # 单线程
            ansible_logger.info("单线程 ...")
            for ip, ip2 in self.ogz_ip_pair.items():
                try:
                    str_ips = ip + "," + " ".join(ip2)
                    ansible_logger.info(str_ips)
                    self.run_check(str_ips)
                except Exception as e:
                    ansible_logger.info(e)
        # TODO 记录操作记录
        # ...
        # ansible_logger.info(self.check_result)
        # ansible_logger.info(self.stdout)
        all_result = []
        all_result_dict = {}
        try:
            all_result = [d.get('result2') for d in self.check_result]
            # TODO 判定每行（一对ip）的结果 多余
            for ee in all_result:
                for e in ee.split('\n'):
                    arr = e.split(',')
                    ip = arr[0]
                    ip2 = arr[1]
                    k = ip + ',' + ip2
                    v = ','.join(arr[2:])       # 值？
                    s, s2, s3, s4 = self.get_status(str(e))     # 判定每行（一对ip）的结果
                    all_result_dict[k] = {"ip": ip, "ip2": ip2, "result": v, "status": s2}
        except:
            pass

        return {
            'code': 200,
            'msg': 'OK',
            'result': self.check_result,
            'stdout': self.stdout,
            'all_result': all_result,
            'all_result_dict': all_result_dict
        }

    def check_status(self, res):
        new_res = []
        new_res2 = []       # 无格式的结果
        status_dict = {}
        for k in self.all_status_html:
            status_dict.setdefault(k, 0)

        for str_res in '\n'.join(res).split('\n'):
            code, stat, new_str_res, new_str_res2 = self.get_status(str_res)       # 对某行结果的判定
            new_res.append(new_str_res)
            new_res2.append(new_str_res2)
            status_dict[code] += 1

        status = ''.join(["{} {} </code>".format(self.all_status_html.get(k), v)
                         for k, v in status_dict.items()])
        status2 = ''.join(["{}{} ".format(self.all_status.get(k), v)
                          for k, v in status_dict.items()])
        # 分隔、重新追加的new_res元素个数相对于res可能已发生改变，但不影响打印结果
        return status, new_res, status2, new_res2

    def get_status(self, str_res):
        status_code = "3"
        if 'error' in str_res:
            status_code = "3"
        elif '%' in str_res:
            per = int(str_res.split('%')[0].split(',')[-1])
            if per < 5:
                status_code = "0"
            elif per < 20:
                status_code = "1"
            else:
                status_code = "2"
        status = self.all_status2.get(status_code)
        # new_str_res = str_res + "," + status      # 不能处理尾部多余的逗号
        new_str_res2 = ','.join(str_res.replace(',', ' ').strip().split(' ') + [status])
        status_html = self.all_status_html2.get(status_code)
        new_str_res = ','.join(str_res.replace(',', ' ').strip().split(' ') + [status_html])
        return status_code, status, new_str_res, new_str_res2

    def run_check(self, str_ips):
        """
        执行检测（多线程执行单元）
        :param str_ips: 字符串 单次检测ip列表 形如"ip,ip2" 或 "ip,ip2 ip3 ip4"
        :return:
        """

        ip, ip2s = str_ips.split(',')
        res = []  # 当前ip_pair的命令结果
        try:
            ansible_logger.info("run check ..." + str_ips)
            server_obj = ServerAssets.objects.select_related('assets').get(
                assets__asset_management_ip=ip)
            resource = [
                {
                    "ip": server_obj.assets.asset_management_ip,
                    "port": int(server_obj.port),
                    "username": server_obj.username,
                    "password": CryptPwd().decrypt_pwd(server_obj.password)
                }
            ]
            ans = ANSRunner(resource, become='yes', become_method='sudo', become_user='root',
                            sock=self.sock, timeout=5)
            # ping序列检测命令
            # module_args = """ping -c 100 -i 0.002 -w 2 {} |tail -n2""" \
            #               """ |sed 's#[^0-9%\.]\+#,#g;s/^,\+//;s/,\+$//;'""" \
            #               '|sed ":a;N;s/\\n/,/g;ta"'.format(ip2)
            module_args = """for i in {ip2s};do echo -n "{ip},$i,"; """ \
                          """ping -c 100 -i 0.002 -w 2 $i |tail -n2 """ \
                          """|sed "s#[^0-9%\.]\+#,#g;s/^,\+//;s/,\+$//" """ \
                          """|sed ":a;N;s/\\n/,/g;ta";done""".format(ip=ip, ip2s=ip2s)
            ansible_logger.info("current ip -> ip2s & module args:")
            ansible_logger.info(ip + "->" + ip2s)
            ansible_logger.info(module_args)
            ans.run_module(host_list=[ip],
                           module_name="shell",
                           module_args=module_args)
            ansible_logger.info(ip + "->" + ip2s + " run module ok")
            if not str(ans.get_module_results[0]).startswith(ip):
                raise ValueError
            res.extend(ans.get_module_results)
            self.stdout.extend(ans.get_module_html)
        except Exception as e:
            ansible_logger.error(e)
            # ansible未能执行的，不能通过ans.get_module_results获取结果，设定结果为error
            self.stdout.append('<code style="color: #FF0000">{}->{}: failed. {}</code><br><br>'
                               .format(ip, ip2s, e))
            for ip2 in ip2s.split(' '):
                res.append("{},{},error".format(ip, ip2))
        finally:
            # 结果判定
            status, new_res, status2, new_res2 = self.check_status(res)
            self.check_result.append(
                {
                    "tag": ip + "->" + ip2s,
                    "ip": ip,
                    "ip2": ip2s,
                    "result": '\n'.join(new_res),
                    "status": status,
                    "result2": '\n'.join(new_res2),
                    "status2": status2
                }
            )

