# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：      urls
   Description:
   Author:          Administrator
   date：           2018/6/11
-------------------------------------------------
   Change Activity:
                    2018/6/11:
-------------------------------------------------
"""
from django.urls import path, re_path
from task import views

urlpatterns = [
    path(r'inventory/', views.gen_inventory, name='inventory'),
    path(r'run_module/', views.run_module, name='run_module'),
    path(r'run_log/', views.run_log, name='run_log'),

    path(r'playbook_add/', views.playbook_add, name='playbook_add'),
    path(r'playbook_upload/', views.playbook_upload, name='playbook_upload'),
    path(r'playbook_list/', views.playbook_list, name='playbook_list'),
    re_path(r'playbook_del/(?P<pk>[0-9]+)/', views.playbook_del, name='playbook_del'),
    re_path(r'playbook_run/(?P<pk>[0-9]+)/', views.playbook_run, name='playbook_run'),
    re_path(r'playbook_info/(?P<pk>[0-9]+)/', views.playbook_info, name='playbook_info'),

    re_path(r'(?P<category>\w+)/list/', views.item_list, name='item_list'),
    re_path(r'(?P<category>\w+)/edit/', views.item_edit, name='item_edit'),
    re_path(r'(?P<category>\w+)/add/', views.item_add, name='item_add'),
    re_path(r'(?P<category>\w+)/detail/(?P<pk>[0-9]+)/', views.item_detail, name='item_detail'),
    re_path(r'(?P<category>\w+)/del/(?P<pk>[0-9]+)/', views.item_del, name='item_del'),

    path(r'path_del/', views.path_del, name='path_del'),
    path(r'path_create/', views.path_create, name='path_create'),
    path(r'get_file_content/', views.get_file_content, name='get_file_content'),

    re_path(r'playbook_log_del/(?P<pk>[0-9]+)/', views.playbook_log_del, name='playbook_log_del'),
    re_path(r'module_log_del/(?P<pk>[0-9]+)/', views.module_log_del, name='module_log_del'),
    re_path(r'(?P<category>\w+)/check_add/(?P<pk>[0-9]+)/', views.check_add, name='check_add'),
    path(r'check_name/', views.check_name, name='check_name'),
    path(r'get_inventory_hosts/', views.get_inventory_hosts, name='get_inventory_hosts')
]
