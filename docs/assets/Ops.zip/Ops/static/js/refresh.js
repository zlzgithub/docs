
    $('#refresh-consul-data').on('click', function () {
            url = "{% url 'update_consul_data' %}";
            alert(url);
            $.get(url, function (res) {
                if (res.code === 200) {
                    $.alert({
                        title: '提示',
                        type: 'green',
                        content: 'Consul数据' + res.msg
                    });
                    //重载
                    table.ajax.reload(function (res) {
                        //
                    });
                } else {
                    $.alert({
                        title: '提示',
                        type: 'red',
                        content: 'Consul数据' + res.msg
                    });
                }
            });
        });