define(function (require, exports, module) {

  module.exports = {
    Sentry: require("./zsentry"),
  };

});