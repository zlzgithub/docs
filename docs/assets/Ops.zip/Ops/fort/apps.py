from django.apps import AppConfig


class FortConfig(AppConfig):
    name = 'fort'
