from django.apps import AppConfig


class PromConfig(AppConfig):
    name = 'prom'
