import json
import re

import bs4
import requests
import datetime, time
import random
from django.contrib import auth
from django.http import HttpResponseRedirect, HttpResponse, JsonResponse
from django.shortcuts import redirect, render
from assets.models import *
from users.models import UserProfile
from projs.models import Project
from fort.models import FortServer
from utils.gen_random_code import generate
from utils.decorators import admin_auth
from utils.crypt_pwd import CryptPwd
from utils.db.mongo_ops import MongoOps, JSONEncoder
from io import BytesIO
from django.conf import settings
from commons.tasks import get_login_info
from task.utils.ansible_api_v2 import ANSRunner
from django.contrib.auth.decorators import permission_required
from task.utils.check_tools import CheckTools
from task.models import AnsibleInventory
from conf.logger import ansible_logger, user_logger
from bs4 import BeautifulSoup


mongo_prom = MongoOps(
    settings.MONGODB_HOST,
    settings.MONGODB_PORT,
    settings.RECORD_DB,
    "prom_rules",
    settings.MONGODB_USER,
    settings.MONGODB_PASS
)


def fmt_data(data):
    res = []
    patt = re.compile('^\s*\w+:')
    for line in data.splitlines():
        m = patt.match(line)
        if m:
            res.append(line.rstrip())
        else:
            if len(res) > 0:
                res[-1] += line.rstrip()
                ansible_logger.info(res[-1])
    return "\n".join(res)


@admin_auth
def sync_rules_data(request):
    ansible_logger.info("[coll rules data]")
    resp = requests.get("http://172.17.0.13:9090/rules")
    nodes = [{"node1": "http://172.17.0.13:9090/rules"}]
    if resp.status_code == 200:
        soup = BeautifulSoup(resp.content)
        table = soup.table
        groups = []
        group_info = {}
        n_heads = len(table.find_all('thead'))
        for i in range(n_heads):
            gn = ""
            for e in table.select("thead")[i]:
                if type(e) is not bs4.element.NavigableString:
                    g = e.select("td")[0]
                    gn = g.text
                    groups.append(g.text)
            # tbody
            is_first = True
            for e in table.select("tbody")[i]:
                if type(e) is not bs4.element.NavigableString:
                    if is_first:
                        is_first = False
                        continue

                    rule = e.select("td")[0].text
                    rn = e.select("td")[0].select("a")[0].text
                    fmt_rule = fmt_data(rule)
                    state = e.select("td")[1].text.strip()
                    group_info.setdefault(gn, []).append(
                        {"ds": 1, "gn": gn, "rn": rn, "rule": rule, "fmt_rule": fmt_rule, "state": state})

        ansible_logger.info("===============groups")
        ansible_logger.info(groups)
        ansible_logger.info("===============group info")
        ansible_logger.info(json.dumps(group_info, indent=4))
        for gn in group_info:
            rules = group_info[gn]
            mongo_prom.delete({"ds": 1, "gn": gn})
            mongo_prom.insert_many(rules)

        # return HttpResponse(str(table))
        return JsonResponse({"code": 200, "msg": "更新完毕"})
    else:
        ansible_logger.info("none ...")
        return JsonResponse({"code": 500, "msg": "更新失败"})


@admin_auth
def prom_rules_registered(request):
    return render(request, 'prom/rules_registered.html')


@admin_auth
def prom_rules(request):
    return render(request, 'prom/rules.html')


@admin_auth
def get_rules_data(request, ds):
    """
    :param request:
    :param ds: 0 已注册的  1 现存的
    :return:
    """
    draw = int(request.GET.get('draw'))  # 记录操作次數
    start = int(request.GET.get('start'))  # 起始位置
    length = int(request.GET.get('length'))  # 每页长度
    s_name = request.GET.get('s_name')
    order_col = request.GET.get('order[0][column]')
    order_col_name = request.GET.get('columns[{}][data]'.format(order_col))
    order_type = 1 if request.GET.get('order[0][dir]') == 'asc' else -1
    dc = request.GET.get('dc')
    search_options = {"ds": int(ds)}
    try:
        if s_name:
            search_options.update({"Name": {"$regex": f".*{s_name}.*"}})
        if dc:
            search_options.update({"dc": dc})

        searched_data, _ = mongo_prom.find(search_options, start, length,
                                           sort_key=order_col_name, sort_method=order_type)
        _, count = mongo_prom.find(search_options)
        dic = {
            'draw': draw,
            'recordsFiltered': count,
            'recordsTotal': count,
            'data': searched_data
        }
        ansible_logger.info("dic is: -------------------")
        ansible_logger.info(dic)
        return HttpResponse(json.dumps(dic, cls=JSONEncoder), content_type='application/json')
        # return JsonResponse({'code': 200, 'data': dic, 'msg': 'OK'})
    except Exception as e:
        return JsonResponse({'code': 500, 'data': [], 'msg': u'获取失败：{}'.format(e)})


@admin_auth
def prom_rule_info(request):
    return render(request, 'prom/prom_rules.html')


@admin_auth
def prom_settings(request):
    return render(request, 'prom/prom_rules.html')


@admin_auth
def service_info(request):
    ansible_logger.info("[service_info] ...")
    s_name = request.GET.get("s_name")
    dc = request.GET.get("dc") or "dc01"
    ansible_logger.info("s_name: " + s_name)
    return render(request, 'prom/service_info.html', locals())


@admin_auth
def get_prom_data(request):
    mongo = MongoOps(settings.MONGODB_HOST,
                     settings.MONGODB_PORT,
                     settings.RECORD_DB,
                     settings.CONSUL_MONGO_COLL,
                     settings.MONGODB_USER,
                     settings.MONGODB_PASS)
    draw = int(request.GET.get('draw'))  # 记录操作次數
    start = int(request.GET.get('start'))  # 起始位置
    length = int(request.GET.get('length'))  # 每页长度
    # start_time = request.GET.get('startTime')
    # end_time = request.GET.get('endTime')
    s_name = request.GET.get('s_name')
    dc = request.GET.get('dc')
    search_options = {}
    try:
        if s_name:
            search_options.update({"Name": {"$regex": f".*{s_name}.*"}})
        # if start_time and end_time:
        #     start_time = datetime.datetime.strptime(start_time, '%Y-%m-%d')
        #     end_time = datetime.datetime.strptime(end_time, '%Y-%m-%d') + datetime.timedelta(1)
        #     search_options.update({"datetime": {"$gt": start_time, "$lt": end_time}})
        searched_data, _ = mongo.find(search_options, start, length, sort_key='Name', sort_method=1)
        _, count = mongo.find(search_options)
        dic = {
            'draw': draw,
            'recordsFiltered': count,
            'recordsTotal': count,
            'data': searched_data
        }
        return HttpResponse(json.dumps(dic, cls=JSONEncoder), content_type='application/json')
    except Exception as e:
        return JsonResponse({'code': 500, 'data': None, 'msg': '获取失败：{}'.format(e)})


@admin_auth
def update_prom_data(request):
    mongo = MongoOps(settings.MONGODB_HOST,
                     settings.MONGODB_PORT,
                     settings.RECORD_DB,
                     settings.CONSUL_MONGO_COLL,
                     settings.MONGODB_USER,
                     settings.MONGODB_PASS)
    headers = {
        "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
    }
    resp = requests.get("http://172.17.0.13:8500/v1/internal/ui/services?dc=dc1", headers=headers)
    if 200 == resp.status_code:
        c_data = json.loads(resp.content)
        # mongo.insert_many(c_data)
        for c in c_data:
            # c["_id"] = c["Name"]
            # 更新，无则新增
            mongo.update_insert_one_by_key(c, "Name")
            # mongo.update_one_by_id(c)

    return JsonResponse({"code": 200, "msg": "更新完毕"})


@admin_auth
def get_service_info(request):
    """
    前端分页即可
    :param request:
    :return:
    """
    ansible_logger.info("[get_service_info]")
    s_name = request.GET.get('s_name')
    dc = request.GET.get('dc') or "dc1"
    ansible_logger.info("s_name={}, dc ={}".format(s_name, dc))
    headers = {
        "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
    }
    resp = requests.get("http://172.17.0.13:8500/v1/health/service/{}?dc={}".format(s_name, dc), headers=headers)
    # resp = requests.get("http://172.17.0.13:8500/v1/internal/ui/services?dc=dc1", headers=headers)
    ansible_logger.info("[get_service_info] resp code:" + str(resp.status_code))
    ansible_logger.info("???")
    if 200 == resp.status_code:
        c_data = json.loads(resp.content)
        # return HttpResponse(json.dumps({'data': c_data}, cls=JSONEncoder), content_type='application/json')
        ansible_logger.info("c_data")
        ansible_logger.info(c_data)
        return JsonResponse({'code': 200, 'data': c_data, 'msg': '获取成功'}, encoder=JSONEncoder)
    else:
        return JsonResponse({'code': 500, 'data': None, 'msg': '获取失败，{}'.format(resp.content)})


@admin_auth
def deregister_service(request):
    """
    注销服务
    :param request:
    :return:
    """
    ansible_logger.info("[deregister_service]")
    s_id = request.POST.get('s_id')
    dc = request.GET.get('dc') or "dc1"
    ansible_logger.info("s_id={}, dc ={}".format(s_id, dc))
    headers = {
        "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
    }
    url_tmpl = "http://172.17.0.13:8500/v1/agent/service/deregister/{id}"
    resp = requests.put(url_tmpl.format(id=s_id), headers=headers)
    if 200 == resp.status_code:
        return JsonResponse({'code': 200, 'msg': '注销成功'}, encoder=JSONEncoder)
    else:
        return JsonResponse({'code': 500, 'msg': '注销失败，{}'.format(resp.content)})
