"""Ops URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path, include, re_path
from django.views.static import serve
from django.conf import settings
from prom import views


urlpatterns = [
    path('sync_rules_data/', views.sync_rules_data, name='sync_rules_data'),
    path('update_prom_data/', views.update_prom_data, name='update_prom_data'),
    path('rules_info/', views.prom_rule_info, name='prom_rule_info'),
    path('rules/', views.prom_rules, name='prom_rules'),
    path('rules_reg/', views.prom_rules_registered, name='prom_rules_registered'),
    path('settings/', views.prom_settings, name='prom_settings'),
    re_path(r'get_rules_data/(?P<ds>[0-9]+)/', views.get_rules_data, name='get_rules_data'),
]
