from django.db import models


# Create your models here.
class WebSite(models.Model):
    web_name = models.CharField(max_length=32, verbose_name='网站名称')
    web_address = models.URLField(verbose_name='网站地址')
    web_des = models.CharField(max_length=32, verbose_name='网站描述')

    class Meta:
        db_table = 'ops_website'
        verbose_name = '常用网站表'
        verbose_name_plural = '常用网站表'
